package com.skilltracker.servicesImpl;

import java.util.List;

import com.skilltracker.dtos.TeamDTO;
import com.skilltracker.services.TeamService;

public class TeamServiceImpl implements TeamService {

	@Override
	public List<TeamDTO> getAllTeam() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TeamDTO saveTeam(TeamDTO TeamDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TeamDTO deleteTeam(String teamId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TeamDTO updateTeam(TeamDTO TeamDTO) {
		// TODO Auto-generated method stub
		return null;
	}

}
