package com.skilltracker.servicesImpl;

import java.util.List;

import com.skilltracker.dtos.UserDTO;
import com.skilltracker.services.UserService;

public class UserServiceImpl implements UserService {

	@Override
	public List<UserDTO> getAllUser() {

		return null;
	}

	@Override
	public UserDTO saveUser(UserDTO UserDTO) {

		return null;
	}

	@Override
	public UserDTO deleteUser(String userId) {

		return null;
	}

	@Override
	public UserDTO updateUser(UserDTO UserDTO) {

		return null;
	}

	@Override
	public UserDTO getUserByFirstName(UserDTO userfName) {
		
		return null;
	}

	@Override
	public UserDTO getUserByEmail(UserDTO userEmail) {
		
		return null;
	}

}
